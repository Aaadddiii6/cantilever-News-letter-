# React + Vite

This website is created for the cantilever internship (project 2)
